# phpProject

This is a basic Web page using PHP.
# It consists of :
  User Registration portal.
  User Details entered into mysql database.
  Email verification using PHP mailer.
  Login Portal.
  Dashborad Portal(only for authorized users).
  Navigation bar.
  Logout Portal.
  Resend Email Verification link.
  Forgot and Reset Password Portal.
  Resetting password email link.
  Password changing.

# Technologies used:
  PHP
  MYSQL
  APACHE SERVER
  PHP MAILER
  
  
